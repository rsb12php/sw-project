class People{

    public birth_year:string
    public eye_color:string
    public films:string[]
    public gender:string
    public hair_color:string
    public height:string
    public homeworld:string
    public mass:string
    public name:string
    public skin_color:string
    public created:string
    public edited:string
    public species:string[]
    public starships:string[]
    public url:string
    public vehicles:string[]

}