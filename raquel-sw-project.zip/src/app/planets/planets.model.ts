export class Planets{

    public name:string
    public diameter:string
    public rotation_period:string
    public orbital_period:string
    public gravity:string
    public population:string
    public climate:string
    public terrain:string
    public surface_water:string
    public residents:string[]
    public films:string[]
    public url:string
    public created:string
    public edited:string

}